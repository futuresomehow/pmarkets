import json

from edge_scanner import db, fees, kalshi_client, matching, polymarket_client, sizing
from edge_scanner.config import (
    ARB_MIN_GAP_CENTS_AFTER_FEES,
    FAVORITE_ASSUMED_EDGE,
    FAVORITE_MAX_CENTS,
    FAVORITE_MIN_CENTS,
    MAX_DAYS_TO_RESOLUTION,
    MIN_HOURS_TO_RESOLUTION,
    MIN_VOLUME_DOLLARS,
    MOVER_MIN_DELTA_CENTS,
)
from edge_scanner.timeutil import hours_until, parse_iso


def _passes_filters(market: dict) -> bool:
    if (market.get("volume") or 0.0) < MIN_VOLUME_DOLLARS:
        return False
    hrs = hours_until(market.get("close_time"))
    if hrs is None:
        return False
    return MIN_HOURS_TO_RESOLUTION <= hrs <= MAX_DAYS_TO_RESOLUTION * 24.0


def _favorite_signal(conn, market: dict, scanned_at: str, bankroll: float):
    price = market["price_cents"]
    if not (FAVORITE_MIN_CENTS <= price <= FAVORITE_MAX_CENTS):
        return None

    sized = sizing.size_position(price, FAVORITE_ASSUMED_EDGE, bankroll)
    detail = {"assumed_edge": FAVORITE_ASSUMED_EDGE}
    signal_id = db.insert_signal(
        conn,
        scanned_at=scanned_at,
        signal_type="FAVORITE",
        platform=market["platform"],
        market_id=market["market_id"],
        title=market["title"],
        side="yes",
        price_cents=price,
        edge=FAVORITE_ASSUMED_EDGE,
        contracts=sized["contracts"],
        stake=sized["stake"],
        max_loss=sized["max_loss"],
        detail=json.dumps(detail),
    )
    return {
        "id": signal_id,
        "signal_type": "FAVORITE",
        "platform": market["platform"],
        "market_id": market["market_id"],
        "title": market["title"],
        "side": "yes",
        "price_cents": price,
        "edge": FAVORITE_ASSUMED_EDGE,
        **sized,
        "detail": detail,
    }


def _mover_signal(conn, market: dict, scanned_at: str, previous_price_cents: float):
    delta = market["price_cents"] - previous_price_cents
    if abs(delta) < MOVER_MIN_DELTA_CENTS:
        return None

    detail = {"previous_price_cents": previous_price_cents, "delta_cents": delta}
    signal_id = db.insert_signal(
        conn,
        scanned_at=scanned_at,
        signal_type="MOVER",
        platform=market["platform"],
        market_id=market["market_id"],
        title=market["title"],
        side=None,
        price_cents=market["price_cents"],
        edge=None,
        contracts=None,
        stake=None,
        max_loss=None,
        detail=json.dumps(detail),
    )
    return {
        "id": signal_id,
        "signal_type": "MOVER",
        "platform": market["platform"],
        "market_id": market["market_id"],
        "title": market["title"],
        "side": None,
        "price_cents": market["price_cents"],
        "edge": None,
        "contracts": None,
        "stake": None,
        "max_loss": None,
        "detail": detail,
    }


def _arb_signals(conn, kalshi_markets, poly_markets, scanned_at: str, bankroll: float):
    out = []
    for k, p, similarity in matching.find_matches(kalshi_markets, poly_markets, parse_iso):
        gap_cents = abs(k["price_cents"] - p["price_cents"])
        fee_cents = fees.kalshi_taker_fee_cents_per_contract(k["price_cents"])
        net_gap_cents = gap_cents - fee_cents
        if net_gap_cents <= ARB_MIN_GAP_CENTS_AFTER_FEES:
            continue

        if k["price_cents"] < p["price_cents"]:
            buy_leg, sell_leg = k, p
        else:
            buy_leg, sell_leg = p, k

        edge = net_gap_cents / 100.0
        sized = sizing.size_position(buy_leg["price_cents"], edge, bankroll)
        detail = {
            "title_similarity": round(similarity, 3),
            "gap_cents": round(gap_cents, 2),
            "kalshi_fee_cents": round(fee_cents, 2),
            "net_gap_cents": round(net_gap_cents, 2),
            "buy_platform": buy_leg["platform"],
            "buy_market_id": buy_leg["market_id"],
            "buy_title": buy_leg["title"],
            "buy_price_cents": buy_leg["price_cents"],
            "sell_platform": sell_leg["platform"],
            "sell_market_id": sell_leg["market_id"],
            "sell_title": sell_leg["title"],
            "sell_price_cents": sell_leg["price_cents"],
            "note": "Fuzzy title match -- verify resolution rules match before treating this as a real arb.",
        }
        signal_id = db.insert_signal(
            conn,
            scanned_at=scanned_at,
            signal_type="ARB",
            platform=buy_leg["platform"],
            market_id=buy_leg["market_id"],
            title=buy_leg["title"],
            side="yes",
            price_cents=buy_leg["price_cents"],
            edge=edge,
            contracts=sized["contracts"],
            stake=sized["stake"],
            max_loss=sized["max_loss"],
            detail=json.dumps(detail),
        )
        out.append({
            "id": signal_id,
            "signal_type": "ARB",
            "platform": buy_leg["platform"],
            "market_id": buy_leg["market_id"],
            "title": buy_leg["title"],
            "side": "yes",
            "price_cents": buy_leg["price_cents"],
            "edge": edge,
            **sized,
            "detail": detail,
        })
    return out


def run_scan(conn, bankroll: float, kalshi_markets: list[dict] | None = None, poly_markets: list[dict] | None = None) -> list[dict]:
    scanned_at = db.utcnow()

    if kalshi_markets is None:
        kalshi_markets = kalshi_client.fetch_markets()
    if poly_markets is None:
        poly_markets = polymarket_client.fetch_markets()

    kalshi_filtered = [m for m in kalshi_markets if _passes_filters(m)]
    poly_filtered = [m for m in poly_markets if _passes_filters(m)]
    all_filtered = kalshi_filtered + poly_filtered

    signals = []

    for market in all_filtered:
        previous = db.get_last_price(conn, market["platform"], market["market_id"])

        fav = _favorite_signal(conn, market, scanned_at, bankroll)
        if fav:
            signals.append(fav)

        if previous is not None:
            mover = _mover_signal(conn, market, scanned_at, previous["price_cents"])
            if mover:
                signals.append(mover)

        db.record_price(
            conn,
            market["platform"],
            market["market_id"],
            market["title"],
            market["price_cents"],
            market.get("volume"),
            market.get("close_time"),
            scanned_at,
        )

    signals.extend(_arb_signals(conn, kalshi_filtered, poly_filtered, scanned_at, bankroll))

    conn.commit()
    return signals
