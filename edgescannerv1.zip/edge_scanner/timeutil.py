from datetime import datetime, timezone


def parse_iso(value) -> datetime | None:
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    try:
        text = str(value).replace("Z", "+00:00")
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError:
        return None


def hours_until(value) -> float | None:
    dt = parse_iso(value)
    if dt is None:
        return None
    return (dt - datetime.now(timezone.utc)).total_seconds() / 3600.0
