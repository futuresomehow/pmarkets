import sqlite3
from datetime import datetime, timezone

from edge_scanner.config import DB_PATH, DEFAULT_BANKROLL

SCHEMA = """
CREATE TABLE IF NOT EXISTS config (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS price_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    platform TEXT NOT NULL,
    market_id TEXT NOT NULL,
    title TEXT NOT NULL,
    price_cents REAL NOT NULL,
    volume REAL,
    close_time TEXT,
    scanned_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_price_history_market
    ON price_history (platform, market_id, scanned_at);

CREATE TABLE IF NOT EXISTS signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scanned_at TEXT NOT NULL,
    signal_type TEXT NOT NULL,
    platform TEXT NOT NULL,
    market_id TEXT NOT NULL,
    title TEXT NOT NULL,
    side TEXT,
    price_cents REAL,
    edge REAL,
    contracts INTEGER,
    stake REAL,
    max_loss REAL,
    detail TEXT,
    status TEXT NOT NULL DEFAULT 'open'
);

CREATE TABLE IF NOT EXISTS positions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    signal_id INTEGER,
    platform TEXT NOT NULL,
    market_id TEXT NOT NULL,
    title TEXT NOT NULL,
    signal_type TEXT NOT NULL,
    side TEXT,
    entry_price_cents REAL NOT NULL,
    contracts INTEGER NOT NULL,
    stake REAL NOT NULL,
    thesis TEXT,
    opened_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    resolved_at TEXT,
    outcome TEXT,
    pnl REAL,
    FOREIGN KEY (signal_id) REFERENCES signals (id)
);
"""


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def get_connection(db_path: str = DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    conn.commit()


def get_bankroll(conn: sqlite3.Connection) -> float:
    row = conn.execute("SELECT value FROM config WHERE key = 'bankroll'").fetchone()
    if row is None:
        set_bankroll(conn, DEFAULT_BANKROLL)
        return DEFAULT_BANKROLL
    return float(row["value"])


def set_bankroll(conn: sqlite3.Connection, value: float) -> None:
    conn.execute(
        "INSERT INTO config (key, value) VALUES ('bankroll', ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (str(value),),
    )
    conn.commit()


def get_last_price(conn: sqlite3.Connection, platform: str, market_id: str):
    row = conn.execute(
        "SELECT * FROM price_history WHERE platform = ? AND market_id = ? "
        "ORDER BY scanned_at DESC, id DESC LIMIT 1",
        (platform, market_id),
    ).fetchone()
    return row


def record_price(conn, platform, market_id, title, price_cents, volume, close_time, scanned_at) -> None:
    conn.execute(
        "INSERT INTO price_history (platform, market_id, title, price_cents, volume, close_time, scanned_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (platform, market_id, title, price_cents, volume, close_time, scanned_at),
    )


def insert_signal(conn, **fields) -> int:
    fields.setdefault("status", "open")
    cols = ", ".join(fields.keys())
    placeholders = ", ".join("?" for _ in fields)
    cur = conn.execute(
        f"INSERT INTO signals ({cols}) VALUES ({placeholders})",
        tuple(fields.values()),
    )
    return cur.lastrowid


def get_signal(conn, signal_id: int):
    return conn.execute("SELECT * FROM signals WHERE id = ?", (signal_id,)).fetchone()


def mark_signal_taken(conn, signal_id: int) -> None:
    conn.execute("UPDATE signals SET status = 'taken' WHERE id = ?", (signal_id,))


def insert_position(conn, **fields) -> int:
    cols = ", ".join(fields.keys())
    placeholders = ", ".join("?" for _ in fields)
    cur = conn.execute(
        f"INSERT INTO positions ({cols}) VALUES ({placeholders})",
        tuple(fields.values()),
    )
    return cur.lastrowid


def get_position(conn, position_id: int):
    return conn.execute("SELECT * FROM positions WHERE id = ?", (position_id,)).fetchone()


def resolve_position(conn, position_id: int, outcome: str, pnl: float, resolved_at: str) -> None:
    conn.execute(
        "UPDATE positions SET status = 'resolved', outcome = ?, pnl = ?, resolved_at = ? WHERE id = ?",
        (outcome, pnl, resolved_at, position_id),
    )


def pnl_by_signal_type(conn):
    rows = conn.execute(
        """
        SELECT
            signal_type,
            COUNT(*) AS total,
            SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) AS open_count,
            SUM(CASE WHEN outcome = 'won' THEN 1 ELSE 0 END) AS wins,
            SUM(CASE WHEN outcome = 'lost' THEN 1 ELSE 0 END) AS losses,
            SUM(CASE WHEN status = 'resolved' THEN pnl ELSE 0 END) AS total_pnl
        FROM positions
        GROUP BY signal_type
        ORDER BY signal_type
        """
    ).fetchall()
    return rows
