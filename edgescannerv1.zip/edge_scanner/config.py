import os

DB_PATH = os.environ.get("EDGE_SCANNER_DB", "edge_scanner.db")

DEFAULT_BANKROLL = 1000.0

# --- Liquidity / time-to-resolution filters ---
MIN_VOLUME_DOLLARS = 500.0
MIN_HOURS_TO_RESOLUTION = 1.0
MAX_DAYS_TO_RESOLUTION = 90.0

# --- FAVORITE signal ---
# Longshot bias: markets pricing a near-certain outcome at 90-96c tend to be
# slightly underpriced. This edge is a starting hypothesis, not a fitted
# number -- recalibrate once paper trades give real win-rate data.
FAVORITE_MIN_CENTS = 90.0
FAVORITE_MAX_CENTS = 96.0
FAVORITE_ASSUMED_EDGE = 0.03  # additive probability edge

# --- ARB signal ---
ARB_MIN_GAP_CENTS_AFTER_FEES = 4.0
ARB_TITLE_SIMILARITY_THRESHOLD = 0.6
ARB_MAX_CLOSE_TIME_SKEW_HOURS = 72.0

# --- MOVER signal ---
MOVER_MIN_DELTA_CENTS = 8.0

# --- Sizing ---
MAX_LOSS_FRACTION_OF_BANKROLL = 0.02
KELLY_FRACTION_MULTIPLIER = 0.25

KALSHI_TAKER_FEE_RATE = 0.07  # fee = rate * price * (1 - price), per contract, in dollars
