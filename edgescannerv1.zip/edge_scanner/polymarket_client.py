"""Polymarket public market data client.

Uses the public Gamma API -- no API key required for reads. Gamma prices lag
the live CLOB book slightly; treat them as directional, not exact fills.
"""
import json

import requests

BASE_URL = "https://gamma-api.polymarket.com"


def _as_list(value):
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return []
    return []


def _parse_market(raw: dict) -> dict | None:
    market_id = raw.get("id") or raw.get("conditionId")
    title = raw.get("question")
    if not market_id or not title:
        return None

    outcomes = _as_list(raw.get("outcomes"))
    prices = _as_list(raw.get("outcomePrices"))
    if not outcomes or not prices or len(outcomes) != len(prices):
        return None

    yes_idx = None
    for i, outcome in enumerate(outcomes):
        if str(outcome).strip().lower() == "yes":
            yes_idx = i
            break
    if yes_idx is None:
        yes_idx = 0

    try:
        price_cents = float(prices[yes_idx]) * 100.0
    except (TypeError, ValueError):
        return None

    volume = raw.get("volumeNum")
    if volume is None:
        try:
            volume = float(raw.get("volume") or 0.0)
        except (TypeError, ValueError):
            volume = 0.0

    close_time = raw.get("endDate")

    return {
        "platform": "polymarket",
        "market_id": str(market_id),
        "title": title,
        "price_cents": price_cents,
        "volume": float(volume),
        "close_time": close_time,
    }


def fetch_markets(session: requests.Session | None = None, limit: int = 1000, page_size: int = 200) -> list[dict]:
    session = session or requests
    markets: list[dict] = []
    offset = 0

    while len(markets) < limit:
        params = {"closed": "false", "active": "true", "limit": page_size, "offset": offset}
        resp = session.get(f"{BASE_URL}/markets", params=params, timeout=30)
        resp.raise_for_status()
        page = resp.json()
        if not page:
            break

        for raw in page:
            parsed = _parse_market(raw)
            if parsed:
                markets.append(parsed)

        if len(page) < page_size:
            break
        offset += page_size

    return markets[:limit]
