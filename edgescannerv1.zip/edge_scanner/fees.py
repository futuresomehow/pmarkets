import math

from edge_scanner.config import KALSHI_TAKER_FEE_RATE


def kalshi_taker_fee_dollars(price_cents: float, contracts: int = 1) -> float:
    """Approximate Kalshi taker fee for a given fill price and size.

    fee = ceil(rate * price * (1 - price) * contracts * 100) / 100

    This mirrors Kalshi's published fee formula but is an approximation --
    verify against your account's actual fee schedule before trusting it
    for real sizing.
    """
    p = price_cents / 100.0
    raw = KALSHI_TAKER_FEE_RATE * p * (1 - p) * contracts
    return math.ceil(raw * 100) / 100.0


def kalshi_taker_fee_cents_per_contract(price_cents: float) -> float:
    return kalshi_taker_fee_dollars(price_cents, contracts=1) * 100.0
