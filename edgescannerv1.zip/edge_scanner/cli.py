import argparse
import json
import sys

from edge_scanner import db
from edge_scanner import signals as signals_mod

TITLE_WIDTH = 48


def _truncate(text: str, width: int = TITLE_WIDTH) -> str:
    return text if len(text) <= width else text[: width - 1] + "…"


def _print_scan_table(signals: list[dict], bankroll: float) -> None:
    if not signals:
        print("No signals this scan.")
        return

    print(f"bankroll: ${bankroll:,.2f}\n")
    by_type = {}
    for s in signals:
        by_type.setdefault(s["signal_type"], []).append(s)

    for signal_type in ("FAVORITE", "ARB", "MOVER"):
        rows = by_type.get(signal_type, [])
        if not rows:
            continue
        print(f"-- {signal_type} ({len(rows)}) --")
        for s in rows:
            title = _truncate(s["title"])
            if signal_type == "MOVER":
                d = s["detail"]
                print(f"  #{s['id']:<4} [{s['platform']:>10}] {title:<{TITLE_WIDTH}} "
                      f"{d['previous_price_cents']:.0f}c -> {s['price_cents']:.0f}c "
                      f"({d['delta_cents']:+.0f}c)")
            else:
                print(f"  #{s['id']:<4} [{s['platform']:>10}] {title:<{TITLE_WIDTH}} "
                      f"{s['price_cents']:.0f}c  edge={s['edge']:.3f}  "
                      f"size={s['contracts']} contracts (${s['stake']:.2f}, max loss ${s['max_loss']:.2f})")
        print()


def cmd_scan(args) -> None:
    conn = db.get_connection()
    db.init_db(conn)

    if args.bankroll is not None:
        db.set_bankroll(conn, args.bankroll)
    bankroll = db.get_bankroll(conn)

    result = signals_mod.run_scan(conn, bankroll)

    if args.json:
        print(json.dumps(result, indent=2, default=str))
    else:
        _print_scan_table(result, bankroll)

    conn.close()


def cmd_take(args) -> None:
    conn = db.get_connection()
    db.init_db(conn)

    signal = db.get_signal(conn, args.signal_id)
    if signal is None:
        print(f"No signal #{args.signal_id}.", file=sys.stderr)
        sys.exit(1)
    if signal["status"] != "open":
        print(f"Signal #{args.signal_id} was already taken.", file=sys.stderr)
        sys.exit(1)
    if signal["signal_type"] == "MOVER":
        print("MOVER signals are flagged for review, not auto-sized -- "
              "investigate manually before trading.", file=sys.stderr)
        sys.exit(1)
    if not signal["contracts"]:
        print(f"Signal #{args.signal_id} sized to 0 contracts at current bankroll -- skipping.", file=sys.stderr)
        sys.exit(1)

    opened_at = db.utcnow()
    position_id = db.insert_position(
        conn,
        signal_id=signal["id"],
        platform=signal["platform"],
        market_id=signal["market_id"],
        title=signal["title"],
        signal_type=signal["signal_type"],
        side=signal["side"],
        entry_price_cents=signal["price_cents"],
        contracts=signal["contracts"],
        stake=signal["stake"],
        thesis=args.thesis,
        opened_at=opened_at,
        status="open",
    )
    db.mark_signal_taken(conn, signal["id"])
    conn.commit()

    print(f"Opened position #{position_id}: {signal['contracts']} contracts of "
          f"'{signal['title']}' @ {signal['price_cents']:.0f}c (stake ${signal['stake']:.2f})")
    conn.close()


def cmd_resolve(args) -> None:
    conn = db.get_connection()
    db.init_db(conn)

    position = db.get_position(conn, args.position_id)
    if position is None:
        print(f"No position #{args.position_id}.", file=sys.stderr)
        sys.exit(1)
    if position["status"] != "open":
        print(f"Position #{args.position_id} was already resolved.", file=sys.stderr)
        sys.exit(1)

    entry_prob = position["entry_price_cents"] / 100.0
    if args.outcome == "won":
        pnl = round(position["contracts"] * (1 - entry_prob), 2)
    else:
        pnl = round(-position["stake"], 2)

    db.resolve_position(conn, position["id"], args.outcome, pnl, db.utcnow())
    conn.commit()

    print(f"Position #{position['id']} resolved {args.outcome}: pnl ${pnl:+.2f}")
    conn.close()


def cmd_pnl(args) -> None:
    conn = db.get_connection()
    db.init_db(conn)

    rows = db.pnl_by_signal_type(conn)
    if not rows:
        print("No positions yet.")
        return

    total_trades = total_wins = total_losses = total_open = 0
    total_pnl = 0.0

    print(f"{'signal':<10} {'trades':>7} {'open':>6} {'wins':>6} {'losses':>7} {'win%':>7} {'pnl':>10}")
    for row in rows:
        resolved = row["wins"] + row["losses"]
        win_pct = (row["wins"] / resolved * 100.0) if resolved else 0.0
        print(f"{row['signal_type']:<10} {row['total']:>7} {row['open_count']:>6} {row['wins']:>6} "
              f"{row['losses']:>7} {win_pct:>6.1f}% {row['total_pnl']:>10.2f}")
        total_trades += row["total"]
        total_open += row["open_count"]
        total_wins += row["wins"]
        total_losses += row["losses"]
        total_pnl += row["total_pnl"]

    resolved = total_wins + total_losses
    win_pct = (total_wins / resolved * 100.0) if resolved else 0.0
    print("-" * 62)
    print(f"{'TOTAL':<10} {total_trades:>7} {total_open:>6} {total_wins:>6} "
          f"{total_losses:>7} {win_pct:>6.1f}% {total_pnl:>10.2f}")

    if resolved < 30:
        print(f"\n{30 - resolved} more closed trades until the 30-trade signal-quality checkpoint.")

    conn.close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="scanner.py", description="Edge Scanner v1")
    sub = parser.add_subparsers(dest="command", required=True)

    p_scan = sub.add_parser("scan", help="Pull markets and flag signals")
    p_scan.add_argument("--json", action="store_true", help="Emit machine-readable JSON")
    p_scan.add_argument("--bankroll", type=float, default=None, help="Set/update bankroll for sizing")
    p_scan.set_defaults(func=cmd_scan)

    p_take = sub.add_parser("take", help="Open a paper position from a signal")
    p_take.add_argument("signal_id", type=int)
    p_take.add_argument("thesis", type=str)
    p_take.set_defaults(func=cmd_take)

    p_resolve = sub.add_parser("resolve", help="Resolve a paper position")
    p_resolve.add_argument("position_id", type=int)
    p_resolve.add_argument("outcome", choices=["won", "lost"])
    p_resolve.set_defaults(func=cmd_resolve)

    p_pnl = sub.add_parser("pnl", help="Show P&L broken out by signal type")
    p_pnl.set_defaults(func=cmd_pnl)

    return parser


def main(argv=None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
