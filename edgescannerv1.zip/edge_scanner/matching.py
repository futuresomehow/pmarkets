"""Fuzzy cross-platform market matching for ARB detection.

Title similarity is a heuristic, not a guarantee of identical resolution
rules -- always verify a flagged pair manually before treating it as a real
arbitrage.
"""
import re
from difflib import SequenceMatcher

from edge_scanner.config import ARB_MAX_CLOSE_TIME_SKEW_HOURS, ARB_TITLE_SIMILARITY_THRESHOLD


def _normalize(title: str) -> str:
    title = title.lower()
    title = re.sub(r"[^a-z0-9\s]", " ", title)
    return re.sub(r"\s+", " ", title).strip()


def title_similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, _normalize(a), _normalize(b)).ratio()


def _hours_between(a, b) -> float | None:
    if a is None or b is None:
        return None
    try:
        return abs((a - b).total_seconds()) / 3600.0
    except TypeError:
        return None


def find_matches(kalshi_markets: list[dict], polymarket_markets: list[dict], parse_close_time) -> list[tuple[dict, dict, float]]:
    """Return (kalshi_market, polymarket_market, similarity) tuples for
    markets that look like the same underlying question on both platforms.
    """
    matches = []
    for k in kalshi_markets:
        k_close = parse_close_time(k.get("close_time"))
        for p in polymarket_markets:
            sim = title_similarity(k["title"], p["title"])
            if sim < ARB_TITLE_SIMILARITY_THRESHOLD:
                continue
            p_close = parse_close_time(p.get("close_time"))
            skew = _hours_between(k_close, p_close)
            if skew is not None and skew > ARB_MAX_CLOSE_TIME_SKEW_HOURS:
                continue
            matches.append((k, p, sim))
    return matches
