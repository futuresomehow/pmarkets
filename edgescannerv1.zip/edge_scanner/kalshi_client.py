"""Kalshi public market data client.

Uses Kalshi's public v2 markets endpoint -- no API key required for reads.
Response field names occasionally drift; adjust `_parse_market` if your
first live run comes back with an unexpected shape.
"""
import requests

BASE_URL = "https://api.elections.kalshi.com/trade-api/v2"


def _parse_market(raw: dict) -> dict | None:
    ticker = raw.get("ticker")
    title = raw.get("title") or raw.get("subtitle")
    if not ticker or not title:
        return None

    yes_bid = raw.get("yes_bid")
    yes_ask = raw.get("yes_ask")
    last_price = raw.get("last_price")

    price_cents = yes_ask if yes_ask else (last_price if last_price else yes_bid)
    if price_cents is None:
        return None

    close_time = raw.get("close_time") or raw.get("expiration_time")

    return {
        "platform": "kalshi",
        "market_id": ticker,
        "title": title,
        "price_cents": float(price_cents),
        "volume": float(raw.get("volume") or 0.0),
        "close_time": close_time,
    }


def fetch_markets(session: requests.Session | None = None, status: str = "open", limit: int = 1000) -> list[dict]:
    session = session or requests
    markets: list[dict] = []
    cursor = None

    while True:
        params = {"status": status, "limit": min(limit, 1000)}
        if cursor:
            params["cursor"] = cursor

        resp = session.get(f"{BASE_URL}/markets", params=params, timeout=30)
        resp.raise_for_status()
        payload = resp.json()

        for raw in payload.get("markets", []):
            parsed = _parse_market(raw)
            if parsed:
                markets.append(parsed)

        cursor = payload.get("cursor")
        if not cursor or len(markets) >= limit:
            break

    return markets[:limit]
