from edge_scanner.config import KELLY_FRACTION_MULTIPLIER, MAX_LOSS_FRACTION_OF_BANKROLL


def kelly_fraction(price_prob: float, edge: float, kelly_mult: float = KELLY_FRACTION_MULTIPLIER) -> float:
    """Fraction of bankroll to stake, buying a binary contract at price_prob
    (0-1) with an assumed additive edge over the market-implied probability.
    """
    if price_prob <= 0 or price_prob >= 1:
        return 0.0
    p_win = min(price_prob + edge, 0.99)
    b = (1 - price_prob) / price_prob
    f = (b * p_win - (1 - p_win)) / b
    return max(f, 0.0) * kelly_mult


def size_position(price_cents: float, edge: float, bankroll: float) -> dict:
    """Size a paper position: worst-case loss capped at 2% of bankroll,
    quarter-Kelly on top of that. Returns the smaller (more conservative)
    of the two stakes.

    Worst-case loss on a binary contract bought at price_cents equals the
    full stake (payout goes to zero), so the 2% cap is a direct cap on
    stake size.
    """
    if price_cents <= 0 or price_cents >= 100 or bankroll <= 0:
        return {"contracts": 0, "stake": 0.0, "max_loss": 0.0, "kelly_fraction": 0.0}

    price_prob = price_cents / 100.0
    f = kelly_fraction(price_prob, edge)
    kelly_stake = f * bankroll
    max_loss_stake = MAX_LOSS_FRACTION_OF_BANKROLL * bankroll
    stake = max(min(kelly_stake, max_loss_stake), 0.0)

    contracts = int(stake // price_prob)
    actual_stake = round(contracts * price_prob, 2)

    return {
        "contracts": contracts,
        "stake": actual_stake,
        "max_loss": actual_stake,
        "kelly_fraction": round(f, 4),
    }
