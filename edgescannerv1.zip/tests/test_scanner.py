import json
import os
import re
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from unittest import mock

import pytest

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO_ROOT)

os.environ["EDGE_SCANNER_DB"] = tempfile.mktemp(suffix=".db")

from edge_scanner import cli, db  # noqa: E402


def _future(days: float) -> str:
    return (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()


def _kalshi_fixture(mover_price: float) -> list[dict]:
    return [
        {
            "ticker": "FAVMKT-24",
            "title": "Will the Aurora Comets win the league title",
            "yes_bid": 91,
            "yes_ask": 93,
            "last_price": 92,
            "volume": 10000,
            "close_time": _future(10),
        },
        {
            "ticker": "ARBMKT-24",
            "title": "Candidate Jordan Vance wins the presidential election",
            "yes_bid": 59,
            "yes_ask": 61,
            "last_price": 60,
            "volume": 8000,
            "close_time": _future(20),
        },
        {
            "ticker": "LOWVOL-24",
            "title": "Total eclipse visibility contest in rural Nevada",
            "yes_bid": 93,
            "yes_ask": 94,
            "last_price": 93,
            "volume": 10,  # below liquidity floor -- should be filtered out
            "close_time": _future(5),
        },
        {
            "ticker": "MOVERMKT-24",
            "title": "Precipitation forecast during the downtown parade",
            "yes_bid": mover_price - 1,
            "yes_ask": mover_price + 1,
            "last_price": mover_price,
            "volume": 6000,
            "close_time": _future(15),
        },
    ]


def _poly_fixture() -> list[dict]:
    return [
        {
            "id": "poly-1",
            "question": "Candidate Jordan Vance wins the presidential election",
            "outcomes": json.dumps(["Yes", "No"]),
            "outcomePrices": json.dumps(["0.70", "0.30"]),
            "volumeNum": 9000,
            "endDate": _future(21),
        },
        {
            "id": "poly-2",
            "question": "Falcons Athletic Club promotion playoff outcome",
            "outcomes": json.dumps(["Yes", "No"]),
            "outcomePrices": json.dumps(["0.50", "0.50"]),
            "volumeNum": 5000,
            "endDate": _future(9),
        },
    ]


@pytest.fixture(autouse=True)
def clean_db():
    path = os.environ["EDGE_SCANNER_DB"]
    if os.path.exists(path):
        os.remove(path)
    yield
    if os.path.exists(path):
        os.remove(path)


def _fake_get_dispatcher(kalshi_payload, poly_payload):
    # Both clients fall back to the shared `requests` module when no session
    # is injected, so `requests.get` itself has to be patched once and
    # dispatch by URL -- patching each client module's `requests.get`
    # separately would just overwrite the same underlying attribute twice.
    def fake(url, params=None, timeout=None):
        resp = mock.Mock()
        resp.raise_for_status = mock.Mock()
        resp.json = mock.Mock(return_value=kalshi_payload if "kalshi" in url else poly_payload)
        return resp
    return fake


def _run_scan_cli(capsys, mover_price: float, bankroll: float | None = None) -> list[dict]:
    argv = ["scan", "--json"]
    if bankroll is not None:
        argv += ["--bankroll", str(bankroll)]

    kalshi_payload = {"markets": _kalshi_fixture(mover_price), "cursor": None}
    poly_payload = _poly_fixture()

    # Mock at the HTTP layer (requests.get), not the client functions, so the
    # real fetch + parse pipeline for both APIs is actually exercised.
    with mock.patch("requests.get", side_effect=_fake_get_dispatcher(kalshi_payload, poly_payload)):
        cli.main(argv)

    out = capsys.readouterr().out
    return json.loads(out)


def test_favorite_arb_mover_and_liquidity_filter(capsys):
    first = _run_scan_cli(capsys, mover_price=50.0, bankroll=1000.0)

    by_type = {}
    for s in first:
        by_type.setdefault(s["signal_type"], []).append(s)

    assert len(by_type.get("FAVORITE", [])) == 1
    fav = by_type["FAVORITE"][0]
    assert fav["market_id"] == "FAVMKT-24"
    assert fav["contracts"] > 0
    assert fav["stake"] <= 20.01  # 2% of $1000 bankroll
    assert fav["max_loss"] == fav["stake"]

    assert "LOWVOL-24" not in {s["market_id"] for s in first}

    assert len(by_type.get("ARB", [])) == 1
    arb = by_type["ARB"][0]
    assert arb["platform"] == "kalshi"
    assert arb["market_id"] == "ARBMKT-24"
    assert arb["detail"]["sell_platform"] == "polymarket"
    assert arb["detail"]["net_gap_cents"] > 4.0
    assert arb["contracts"] > 0

    assert by_type.get("MOVER", []) == []  # nothing to compare against on the first scan

    second = _run_scan_cli(capsys, mover_price=62.0)
    movers = [s for s in second if s["signal_type"] == "MOVER"]
    assert len(movers) == 1
    assert movers[0]["market_id"] == "MOVERMKT-24"
    assert movers[0]["detail"]["delta_cents"] == pytest.approx(12.0)


def test_take_resolve_and_pnl_roundtrip(capsys):
    first = _run_scan_cli(capsys, mover_price=50.0, bankroll=1000.0)
    fav_signal = next(s for s in first if s["signal_type"] == "FAVORITE")
    arb_signal = next(s for s in first if s["signal_type"] == "ARB")

    # MOVER can't be taken -- not sized, flagged for review only.
    second = _run_scan_cli(capsys, mover_price=62.0)
    mover_signal = next(s for s in second if s["signal_type"] == "MOVER")
    with pytest.raises(SystemExit):
        cli.main(["take", str(mover_signal["id"]), "should be rejected"])
    capsys.readouterr()

    cli.main(["take", str(fav_signal["id"]), "longshot bias should be underpriced"])
    fav_take_out = capsys.readouterr().out
    fav_position_id = int(re.search(r"Opened position #(\d+)", fav_take_out).group(1))

    cli.main(["take", str(arb_signal["id"]), "cross-platform gap after fees"])
    arb_take_out = capsys.readouterr().out
    arb_position_id = int(re.search(r"Opened position #(\d+)", arb_take_out).group(1))

    conn = db.get_connection()
    fav_position = db.get_position(conn, fav_position_id)
    arb_position = db.get_position(conn, arb_position_id)
    conn.close()

    cli.main(["resolve", str(fav_position_id), "won"])
    fav_resolve_out = capsys.readouterr().out
    expected_fav_pnl = round(fav_position["contracts"] * (1 - fav_position["entry_price_cents"] / 100.0), 2)
    assert f"pnl ${expected_fav_pnl:+.2f}" in fav_resolve_out

    cli.main(["resolve", str(arb_position_id), "lost"])
    arb_resolve_out = capsys.readouterr().out
    expected_arb_pnl = round(-arb_position["stake"], 2)
    assert f"pnl ${expected_arb_pnl:+.2f}" in arb_resolve_out

    # Resolving twice should fail rather than silently double count.
    with pytest.raises(SystemExit):
        cli.main(["resolve", str(fav_position_id), "won"])
    capsys.readouterr()

    cli.main(["pnl"])
    pnl_out = capsys.readouterr().out
    assert "FAVORITE" in pnl_out
    assert "ARB" in pnl_out
    assert "TOTAL" in pnl_out
